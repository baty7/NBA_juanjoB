package org.example;

public class Main {
    public static void main(String[] args) {

        NbaBD nbaBD = new NbaBD();


        nbaBD.leerDatosColeccion();







        nbaBD.cerrarConexion();
    }
}